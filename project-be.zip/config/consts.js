const ADMIN_ID = "a86899a2-e6dd-493d-8ba1-81680f31bd73"
const KOORDINATOR_ID = "229a9fd6-59fa-45fe-a66e-632c8a83db5e"
const KEPALA_ID = "74833f45-8857-424b-b75c-d09e843a9732"
const TEKNISI_ID = "99275883-6088-45da-9669-8d1a3f1a2a67"

const SUP_2 = "²"
const SUP_3 = "³"
const SUP_4 = "⁴"
const SUP_5 = "⁵"
const SUP_6 = "⁶"

module.exports = {
  ADMIN_ID,
  KOORDINATOR_ID,
  KEPALA_ID,
  TEKNISI_ID,
  SUP_2,
  SUP_3,
  SUP_4,
  SUP_5,
  SUP_6,
} 