interface TMetadata {
  app?: {
    name?: string,
    version?: string,
  }
  title?: string
}