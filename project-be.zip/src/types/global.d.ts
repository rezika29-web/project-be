export declare global {
  var DB_PRIMARY:TDB
}
