declare interface String {
  toTitleCase(): string
}