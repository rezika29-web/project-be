interface TApiError {
  isApiError: boolean
  num: number
  message: string
}