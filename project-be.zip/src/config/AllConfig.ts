import EnvyConfig from "./EnvyConfig";

export default {
  envy: EnvyConfig()
}