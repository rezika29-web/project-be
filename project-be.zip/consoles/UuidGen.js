const { v4: uuidv4 } = require("uuid")

console.log('New UUID: ' + uuidv4())
